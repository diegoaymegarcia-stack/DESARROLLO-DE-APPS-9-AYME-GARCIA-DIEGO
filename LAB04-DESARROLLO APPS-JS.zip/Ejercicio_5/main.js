function pipeline(...transformaciones) {
    return function(valorInicial) {
        return transformaciones.reduce(
            (resultado, transformacion) => transformacion(resultado),
            valorInicial
        );
    };
}

const duplicar = n => n * 2;
const sumarDiez = n => n + 10;
const cuadrado = n => n ** 2;

const operacion1 = pipeline(
    duplicar,
    sumarDiez,
    cuadrado
);

const operacion2 = pipeline(
    sumarDiez,
    duplicar,
    cuadrado
);

function ejecutarPipeline1() {
    const resultado = operacion1(5);

    document.getElementById("resultado").innerHTML = `
        <h2>Pipeline 1</h2>
        <p>Valor inicial: 5</p>
        <p>5 → duplicar → 10</p>
        <p>10 → sumar 10 → 20</p>
        <p>20 → cuadrado → 400</p>
        <h3>Resultado final: ${resultado}</h3>
    `;

    console.log("Pipeline 1:", resultado);
}

function ejecutarPipeline2() {
    const resultado = operacion2(5);

    document.getElementById("resultado").innerHTML = `
        <h2>Pipeline 2</h2>
        <p>Valor inicial: 5</p>
        <p>5 → sumar 10 → 15</p>
        <p>15 → duplicar → 30</p>
        <p>30 → cuadrado → 900</p>
        <h3>Resultado final: ${resultado}</h3>
    `;

    console.log("Pipeline 2:", resultado);
}