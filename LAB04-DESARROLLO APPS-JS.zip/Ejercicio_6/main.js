function registrarParticipante(
    nombre,
    edad,
    correo,
    tipo = "general"
) {
    if (!nombre || nombre.trim() === "") {
        throw new Error("El nombre no puede estar vacío");
    }

    edad = Number(edad);

    if (Number.isNaN(edad) || edad < 18) {
        throw new Error("La edad debe ser numérica y mayor o igual a 18");
    }

    if (!correo || correo.trim() === "") {
        throw new Error("El correo no puede estar vacío");
    }

    if (tipo !== "general" && tipo !== "estudiante") {
        throw new Error('El tipo debe ser "general" o "estudiante"');
    }

    const costo = tipo === "estudiante" ? 30 : 50;

    return {
        nombre: nombre,
        edad: edad,
        correo: correo,
        tipo: tipo,
        costo: costo
    };
}

const participantes = [];

function registrarParticipantes() {
    try {
        participantes.push(
            registrarParticipante(
                "Andrea",
                20,
                "andrea@gmail.com",
                "estudiante"
            )
        );

        participantes.push(
            registrarParticipante(
                "Carlos",
                22,
                "carlos@gmail.com",
                "general"
            )
        );

        participantes.push(
            registrarParticipante(
                "Lucía",
                19,
                "lucia@gmail.com",
                "estudiante"
            )
        );

        participantes.push(
            registrarParticipante(
                "Mateo",
                25,
                "mateo@gmail.com",
                "general"
            )
        );

        participantes.push(
            registrarParticipante(
                "Valeria",
                21,
                "valeria@gmail.com",
                "estudiante"
            )
        );

        document.getElementById("resultado").innerHTML = `
            <h2>Participantes registrados</h2>
            <p>Se registraron 5 participantes correctamente.</p>
        `;

        console.log("Participantes:", participantes);
    } catch (error) {
        document.getElementById("resultado").innerHTML = `
            <h2>Error</h2>
            <p>${error.message}</p>
        `;

        console.error("Error:", error.message);
    }
}

function mostrarEstudiantes() {
    const estudiantes = participantes.filter(
        participante => participante.tipo === "estudiante"
    );

    document.getElementById("resultado").innerHTML = `
        <h2>Participantes estudiantes</h2>
        ${estudiantes.map(participante => `
            <p>${participante.nombre} - Edad: ${participante.edad} - Costo: S/ ${participante.costo}</p>
        `).join("")}
    `;

    console.log("Estudiantes:", estudiantes);
}

function mostrarNombres() {
    const estudiantes = participantes.filter(
        participante => participante.tipo === "estudiante"
    );

    const nombres = estudiantes.map(
        participante => participante.nombre
    );

    document.getElementById("resultado").innerHTML = `
        <h2>Nombres de estudiantes</h2>
        <p>${nombres.join(", ")}</p>
    `;

    console.log("Nombres:", nombres);
}

function mostrarTotal() {
    const total = participantes.reduce(
        (acumulador, participante) => acumulador + participante.costo,
        0
    );

    document.getElementById("resultado").innerHTML = `
        <h2>Total recaudado</h2>
        <p>S/ ${total}</p>
    `;

    console.log("Total recaudado: S/", total);
}

function buscarParticipante() {
    const participante = participantes.find(
        participante => participante.correo === "lucia@gmail.com"
    );

    document.getElementById("resultado").innerHTML = `
        <h2>Participante encontrado</h2>
        <p>Nombre: ${participante.nombre}</p>
        <p>Edad: ${participante.edad}</p>
        <p>Correo: ${participante.correo}</p>
        <p>Tipo: ${participante.tipo}</p>
        <p>Costo: S/ ${participante.costo}</p>
    `;

    console.log("Participante encontrado:", participante);
}