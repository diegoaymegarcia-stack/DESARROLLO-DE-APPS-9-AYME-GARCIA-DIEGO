const estudiantes = [
    { nombre: "Andrea", nota: 17 },
    { nombre: "Carlos", nota: 11 },
    { nombre: "Lucía", nota: 19 },
    { nombre: "Mateo", nota: 8 },
    { nombre: "Valeria", nota: 14 }
];

function mostrarNombres() {
    const nombres = estudiantes.map(estudiante => estudiante.nombre);

    document.getElementById("resultado").innerHTML = `
        <h2>Nombres de los estudiantes</h2>
        <p>${nombres.join(", ")}</p>
    `;

    console.log("Nombres:", nombres);
}

function mostrarAprobados() {
    const aprobados = estudiantes.filter(estudiante => estudiante.nota >= 13);

    document.getElementById("resultado").innerHTML = `
        <h2>Estudiantes aprobados</h2>
        ${aprobados.map(estudiante => `
            <p>${estudiante.nombre} - Nota: ${estudiante.nota}</p>
        `).join("")}
    `;

    console.log("Aprobados:", aprobados);
}

function buscarLucia() {
    const lucia = estudiantes.find(estudiante => estudiante.nombre === "Lucía");

    document.getElementById("resultado").innerHTML = `
        <h2>Resultado de búsqueda</h2>
        <p>Nombre: ${lucia.nombre}</p>
        <p>Nota: ${lucia.nota}</p>
    `;

    console.log("Lucía:", lucia);
}

function mostrarPromedio() {
    const suma = estudiantes.reduce(
        (total, estudiante) => total + estudiante.nota,
        0
    );

    const promedio = suma / estudiantes.length;

    document.getElementById("resultado").innerHTML = `
        <h2>Promedio general</h2>
        <p>${promedio}</p>
    `;

    console.log("Promedio:", promedio);
}

function mostrarDesaprobados() {
    const desaprobados = estudiantes.filter(estudiante => estudiante.nota < 13);

    document.getElementById("resultado").innerHTML = `
        <h2>Estudiantes desaprobados</h2>
        <p>Cantidad: ${desaprobados.length}</p>
        ${desaprobados.map(estudiante => `
            <p>${estudiante.nombre} - Nota: ${estudiante.nota}</p>
        `).join("")}
    `;

    console.log("Desaprobados:", desaprobados);
}

function mostrarEstados() {
    const estudiantesConEstado = estudiantes.map(estudiante => ({
        ...estudiante,
        estado: estudiante.nota >= 13 ? "Aprobado" : "Desaprobado"
    }));

    document.getElementById("resultado").innerHTML = `
        <h2>Estado de los estudiantes</h2>
        ${estudiantesConEstado.map(estudiante => `
            <p>${estudiante.nombre} - Nota: ${estudiante.nota} - ${estudiante.estado}</p>
        `).join("")}
    `;

    console.log("Estudiantes con estado:", estudiantesConEstado);
}