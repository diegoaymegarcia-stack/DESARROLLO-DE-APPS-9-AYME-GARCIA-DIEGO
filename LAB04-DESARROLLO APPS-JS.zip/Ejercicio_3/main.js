function crearGeneradorCodigo(prefijo) {
    let contador = 0;

    return function() {
        contador++;
        return `${prefijo}-${contador}`;
    };
}

const generarAlumno = crearGeneradorCodigo("ALU");
const generarDocente = crearGeneradorCodigo("DOC");

function generarCodigoAlumno() {
    const codigo = generarAlumno();

    document.getElementById("resultado").innerHTML = `
        <h2>Código generado</h2>
        <p>${codigo}</p>
    `;

    console.log("Código de alumno:", codigo);
}

function generarCodigoDocente() {
    const codigo = generarDocente();

    document.getElementById("resultado").innerHTML = `
        <h2>Código generado</h2>
        <p>${codigo}</p>
    `;

    console.log("Código de docente:", codigo);
}