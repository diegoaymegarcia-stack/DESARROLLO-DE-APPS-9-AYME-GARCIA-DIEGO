const funciones = [
    {
        id: 1,
        pelicula: "Interstellar",
        sala: 1,
        precio: 18,
        disponibles: 12
    },
    {
        id: 2,
        pelicula: "Dune",
        sala: 2,
        precio: 20,
        disponibles: 5
    },
    {
        id: 3,
        pelicula: "Avengers",
        sala: 3,
        precio: 16,
        disponibles: 0
    },
    {
        id: 4,
        pelicula: "Inception",
        sala: 1,
        precio: 18,
        disponibles: 8
    }
];

function buscarFuncion(id) {
    const funcion = funciones.find(funcion => funcion.id === id);

    if (!funcion) {
        throw new Error("No existe una función con ese ID");
    }

    return funcion;
}

function funcionesDisponibles() {
    return funciones.filter(funcion => funcion.disponibles > 0);
}

function comprarEntradas(id, cantidad) {
    const funcion = buscarFuncion(id);

    if (cantidad <= 0) {
        throw new Error("La cantidad debe ser mayor que cero");
    }

    if (cantidad > funcion.disponibles) {
        throw new Error("No hay suficientes entradas disponibles");
    }

    funcion.disponibles -= cantidad;

    return {
        pelicula: funcion.pelicula,
        cantidad: cantidad,
        total: funcion.precio * cantidad
    };
}

function mostrarFuncionesDisponibles() {
    const disponibles = funcionesDisponibles();

    document.getElementById("resultado").innerHTML = `
        <h2>Funciones disponibles</h2>
        ${disponibles.map(funcion => `
            <p>
                <strong>${funcion.pelicula}</strong>
                | Sala: ${funcion.sala}
                | Precio: S/ ${funcion.precio}
                | Entradas: ${funcion.disponibles}
            </p>
        `).join("")}
    `;

    console.log("Funciones disponibles:", disponibles);
}

function hacerCompra() {
    try {
        const compra = comprarEntradas(1, 2);

        document.getElementById("resultado").innerHTML = `
            <h2>Compra realizada correctamente</h2>
            <p>Película: ${compra.pelicula}</p>
            <p>Cantidad: ${compra.cantidad}</p>
            <p>Total: S/ ${compra.total}</p>
        `;

        console.log("Compra:", compra);
    } catch (error) {
        document.getElementById("resultado").innerHTML = `
            <h2>Error</h2>
            <p>${error.message}</p>
        `;

        console.error(error.message);
    }
}

function probarCompraInvalida() {
    try {
        const compra = comprarEntradas(1, 20);
        console.log(compra);
    } catch (error) {
        document.getElementById("resultado").innerHTML = `
            <h2>Error en la compra</h2>
            <p>${error.message}</p>
        `;

        console.error("Error:", error.message);
    }
}

function probarBusquedaInvalida() {
    try {
        const funcion = buscarFuncion(99);
        console.log(funcion);
    } catch (error) {
        document.getElementById("resultado").innerHTML = `
            <h2>Error de búsqueda</h2>
            <p>${error.message}</p>
        `;

        console.error("Error:", error.message);
    }
}