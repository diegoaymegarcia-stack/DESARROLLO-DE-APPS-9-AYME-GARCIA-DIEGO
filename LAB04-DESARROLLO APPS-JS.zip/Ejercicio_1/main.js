function calcularEnvio(peso, tipo = "normal") {
    peso = Number(peso);

    if (Number.isNaN(peso) || peso <= 0) {
        throw new Error("El peso debe ser un número mayor que cero");
    }

    let costoBase;

    if (peso <= 2) {
        costoBase = 8;
    } else if (peso <= 5) {
        costoBase = 12;
    } else {
        costoBase = 18;
    }

    let costoFinal = costoBase;

    if (tipo === "express") {
        costoFinal = costoBase * 1.40;
    }

    return {
        peso: peso,
        tipo: tipo,
        costoBase: costoBase,
        costoFinal: costoFinal
    };
}

function mostrarEnvioNormal() {
    const envio = calcularEnvio(1.5);

    document.getElementById("resultado").innerHTML = `
        <h2>Resultado</h2>
        <p>Peso: ${envio.peso} kg</p>
        <p>Tipo: ${envio.tipo}</p>
        <p>Costo base: S/ ${envio.costoBase}</p>
        <p>Costo final: S/ ${envio.costoFinal}</p>
    `;

    console.log(envio);
}

function mostrarEnvioExpress() {
    const envio = calcularEnvio(4, "express");

    document.getElementById("resultado").innerHTML = `
        <h2>Resultado</h2>
        <p>Peso: ${envio.peso} kg</p>
        <p>Tipo: ${envio.tipo}</p>
        <p>Costo base: S/ ${envio.costoBase}</p>
        <p>Costo final: S/ ${envio.costoFinal}</p>
    `;

    console.log(envio);
}