
export default function ItemCarrito({
  item,
  onQuitar,
  onCambiarCantidad
}) {
  return (
    <article className="item-carrito">
      <div className="item-imagen">
        <img src={item.image} alt={item.title} />
      </div>

      <div className="item-info">
        <span className="categoria">{item.category}</span>
        <h3>{item.title}</h3>
        <strong>${item.price.toFixed(2)}</strong>

        <div className="item-acciones">
          <div className="control-cantidad">
            <button
              onClick={() => onCambiarCantidad(item.id, -1)}
              aria-label={`Reducir cantidad de ${item.title}`}
            >
              −
            </button>
            <span>{item.cantidad}</span>
            <button
              onClick={() => onCambiarCantidad(item.id, 1)}
              aria-label={`Aumentar cantidad de ${item.title}`}
            >
              +
            </button>
          </div>

          <button
            className="eliminar"
            onClick={() => onQuitar(item.id)}
          >
            Eliminar
          </button>
        </div>
      </div>

      <strong className="item-subtotal">
        ${(item.price * item.cantidad).toFixed(2)}
      </strong>
    </article>
  );
}
