export default function ProductoCard({ producto, onAgregar }) {
  return (
    <article className="producto">
      <div className="producto-imagen">
        <span className="producto-tag">NEXO PICK</span>

        <img
          src={producto.image}
          alt={producto.title}
          loading="lazy"
        />
      </div>

      <div className="producto-info">
        <span className="categoria">
          {producto.category}
        </span>

        <h3 title={producto.title}>{producto.title}</h3>

        <div className="producto-inferior">
          <div>
            <span className="precio-label">PRECIO</span>
            <strong className="precio">
              ${producto.price.toFixed(2)}
            </strong>
          </div>

          <button
            className="boton-agregar"
            onClick={() => onAgregar(producto)}
            aria-label={`Agregar ${producto.title} al carrito`}
            title="Agregar al carrito"
          >
            +
          </button>
        </div>
      </div>
    </article>
  );
}