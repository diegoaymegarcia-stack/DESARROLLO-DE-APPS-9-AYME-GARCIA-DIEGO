
import { Link, useOutletContext } from "react-router-dom";
import ItemCarrito from "./ItemCarrito";

export default function Carrito() {
  const { carrito, quitar, cambiarCantidad } = useOutletContext();

  const total = carrito.reduce(
    (suma, item) => suma + item.price * item.cantidad,
    0
  );

  const cantidad = carrito.reduce(
    (suma, item) => suma + item.cantidad,
    0
  );

  return (
    <section className="pagina-carrito">
      <Link to="/catalogo" className="volver">
        ← Volver a explorar
      </Link>

      <div className="carrito-encabezado">
        <span className="subtitulo">TU SELECCIÓN</span>
        <h1>Mi carrito<span>.</span></h1>
        <p>Las buenas elecciones merecen una segunda mirada.</p>
      </div>

      {carrito.length === 0 ? (
        <div className="carrito-vacio">
          <div className="vacio-icono">N.</div>
          <h2>Aún no hay nada por aquí.</h2>
          <p>Tu próxima compra favorita te está esperando.</p>
          <Link to="/catalogo" className="boton-hero">
            Descubrir productos ↗
          </Link>
        </div>
      ) : (
        <div className="carrito-layout">
          <div className="carrito-lista">
            <h2>Productos seleccionados ({cantidad})</h2>

            {carrito.map((item) => (
              <ItemCarrito
                key={item.id}
                item={item}
                onQuitar={quitar}
                onCambiarCantidad={cambiarCantidad}
              />
            ))}
          </div>

          <aside className="resumen-compra">
            <span className="subtitulo">RESUMEN</span>
            <h2>Tu pedido</h2>

            <div className="resumen-linea">
              <span>Productos ({cantidad})</span>
              <span>${total.toFixed(2)}</span>
            </div>

            <div className="resumen-linea">
              <span>Envío</span>
              <span>A calcular</span>
            </div>

            <div className="resumen-total">
              <span>Total</span>
              <strong>${total.toFixed(2)}</strong>
            </div>

            <p className="resumen-nota">
              Proyecto demostrativo. No se realizan pagos reales.
            </p>

            <Link to="/catalogo" className="boton-seguir">
              Seguir explorando ↗
            </Link>
          </aside>
        </div>
      )}
    </section>
  );
}
