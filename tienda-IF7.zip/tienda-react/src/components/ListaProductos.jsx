
import ProductoCard from "./ProductoCard";

export default function ListaProductos({ productos, onAgregar }) {
  if (productos.length === 0) {
    return (
      <div className="estado">
        <h3>No encontramos coincidencias.</h3>
        <p>Prueba con otro nombre de producto.</p>
      </div>
    );
  }

  return (
    <div className="cuadricula">
      {productos.map((producto) => (
        <ProductoCard
          key={producto.id}
          producto={producto}
          onAgregar={onAgregar}
        />
      ))}
    </div>
  );
}
