
export default function BuscadorProducto({ busqueda, onBusqueda }) {
  return (
    <div className="buscador">
      <span className="buscador-icono" aria-hidden="true">⌕</span>

      <input
        type="search"
        placeholder="¿Qué estás buscando hoy?"
        value={busqueda}
        onChange={(e) => onBusqueda(e.target.value)}
        aria-label="Buscar productos por nombre"
      />

      {busqueda && (
        <button
          type="button"
          className="limpiar"
          onClick={() => onBusqueda("")}
          aria-label="Limpiar búsqueda"
        >
          ✕
        </button>
      )}
    </div>
  );
}
