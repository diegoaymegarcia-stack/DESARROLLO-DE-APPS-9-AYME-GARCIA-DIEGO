
import { useState } from "react";
import { Navigate, NavLink, Outlet, Route, Routes } from "react-router-dom";
import Catalogo from "./pages/Catalogo";
import Carrito from "./components/Carrito";

function Tienda() {
  const [carrito, setCarrito] = useState([]);

  const agregar = (producto) => {
    setCarrito((actual) => {
      const existe = actual.find((item) => item.id === producto.id);

      if (existe) {
        return actual.map((item) =>
          item.id === producto.id
            ? { ...item, cantidad: item.cantidad + 1 }
            : item
        );
      }

      return [...actual, { ...producto, cantidad: 1 }];
    });
  };

  const quitar = (id) => {
    setCarrito((actual) => actual.filter((item) => item.id !== id));
  };

  const cambiarCantidad = (id, cambio) => {
    setCarrito((actual) =>
      actual
        .map((item) =>
          item.id === id
            ? { ...item, cantidad: item.cantidad + cambio }
            : item
        )
        .filter((item) => item.cantidad > 0)
    );
  };

  const cantidad = carrito.reduce(
    (total, item) => total + item.cantidad,
    0
  );

  return (
    <div className="app">
      <header className="cabecera">
        <NavLink to="/catalogo" className="marca">
          <span className="marca-icono">N.</span>
          <span>NEXO<span className="marca-acento">STORE</span></span>
        </NavLink>

        <nav className="navegacion">
          <NavLink to="/catalogo" end>
            Explorar
          </NavLink>
          <NavLink to="/catalogo/carrito" className="nav-carrito">
            Mi carrito <span className="burbuja">{cantidad}</span>
          </NavLink>
        </nav>
      </header>

      <main className="contenido">
        <Outlet context={{ carrito, agregar, quitar, cambiarCantidad }} />
      </main>

      <footer className="pie">
        <span>NEXO STORE © 2026</span>
        <span> Diseñado para destacar.</span>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/catalogo" replace />} />

      <Route path="/catalogo" element={<Tienda />}>
        <Route index element={<Catalogo />} />
        <Route path="carrito" element={<Carrito />} />
      </Route>

      <Route path="*" element={<Navigate to="/catalogo" replace />} />
    </Routes>
  );
}
