
import { useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import ListaProductos from "../components/ListaProductos";
import BuscadorProducto from "../components/BuscadorProducto";

export default function Catalogo() {
  const { agregar } = useOutletContext();

  const [productos, setProductos] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const controlador = new AbortController();

    async function obtenerProductos() {
      try {
        setCargando(true);
        setError("");

        const respuesta = await fetch(
          "https://fakestoreapi.com/products",
          { signal: controlador.signal }
        );

        if (!respuesta.ok) {
          throw new Error("No se pudo conectar con la tienda.");
        }

        const datos = await respuesta.json();

        if (!Array.isArray(datos)) {
          throw new Error("La respuesta de la API no es válida.");
        }

        setProductos(datos);
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(err.message);
        }
      } finally {
        if (!controlador.signal.aborted) {
          setCargando(false);
        }
      }
    }

    obtenerProductos();

    return () => controlador.abort();
  }, []);

  const filtrados = productos.filter((producto) =>
    producto.title.toLowerCase().includes(busqueda.toLowerCase().trim())
  );

  return (
    <section>
      <div className="hero">
        <div className="hero-contenido">
          <span className="etiqueta-hero">
            ✦ TU ESPACIO, TU ESTILO
          </span>

          <h1>
            Lo diferente <br />
            <span>se encuentra aquí.</span>
          </h1>

          <p>
            Explora nuestra colección de productos.
            Encuentra algo que conecte contigo.
          </p>

          <a href="#productos" className="boton-hero">
            Explorar colección <span>↗</span>
          </a>
        </div>

        <div className="hero-decoracion" aria-hidden="true">
          <div className="circulo-grande"></div>
          <span className="hero-letra">N.</span>
          <span className="hero-detalle">EST. 2026 — NEXO</span>
        </div>
      </div>

      <div className="seccion-productos" id="productos">
        <div className="seccion-encabezado">
          <div>
            <span className="subtitulo">EL CATÁLOGO</span>
            <h2>Descubre tu próximo favorito<span>.</span></h2>
          </div>

          <span className="numero-productos">
            {productos.length} PRODUCTOS
          </span>
        </div>

        <BuscadorProducto
          busqueda={busqueda}
          onBusqueda={setBusqueda}
        />

        {cargando ? (
          <div className="estado">
            <div className="spinner"></div>
            <p>Preparando algo bueno para ti...</p>
          </div>
        ) : error ? (
          <div className="estado error">
            <h3>Ups, algo salió mal.</h3>
            <p>{error}</p>
            <button onClick={() => window.location.reload()}>
              Intentar nuevamente
            </button>
          </div>
        ) : (
          <>
            <p className="resultados">
              Mostrando {filtrados.length} productos
            </p>

            <ListaProductos
              productos={filtrados}
              onAgregar={agregar}
            />
          </>
        )}
      </div>
    </section>
  );
}
