# Catálogo de productos con carrito (React)

Ejercicio de React con componentes, `useState`, `useEffect`, `fetch`, buscador controlado y rutas anidadas de React Router.

## Ejecutar en VS Code

1. Descomprime el ZIP y abre la carpeta `tienda-react` en VS Code.
2. Abre una terminal en esa carpeta.
3. Ejecuta `npm install`.
4. Ejecuta `npm run dev`.
5. Abre la URL que indique Vite (normalmente `http://localhost:5173`).

## Rutas
- `/catalogo`: productos cargados desde https://fakestoreapi.com/products
- `/catalogo/carrito`: ruta hija del catálogo para visualizar y eliminar productos.

## Componentes requeridos
`ProductoCard`, `ListaProductos`, `Carrito`, `ItemCarrito`, `BuscadorProducto`.

El estado del carrito vive en el componente contenedor `Tienda` de `App.jsx`. Se transmite a las rutas hijas mediante `Outlet context` (React Router), y desde allí a los componentes mediante props. La búsqueda usa un input controlado. La petición muestra estados de carga y error.

> Requiere Node.js y conexión a Internet para consultar la API. Los precios son los de la API, expresados en USD.
