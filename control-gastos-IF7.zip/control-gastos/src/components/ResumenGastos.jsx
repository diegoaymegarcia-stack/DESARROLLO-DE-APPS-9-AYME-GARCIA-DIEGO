
import React from "react";
import { useSelector } from "react-redux";

export default function ResumenGastos() {
  const gastos = useSelector((state) => state);

  const total = gastos.reduce(
    (suma, gasto) => suma + gasto.monto,
    0
  );

  return (
    <div className="resumen">
      <span>Total gastado</span>
      <h2>S/ {total.toFixed(2)}</h2>
      <p>{gastos.length} gastos registrados</p>
    </div>
  );
}
