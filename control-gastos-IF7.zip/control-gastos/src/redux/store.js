import { createStore } from "redux";
import gastosReducer from "./gastosReducer.js";

export const store = createStore(gastosReducer);
