import { AGREGAR_GASTO, ELIMINAR_GASTO } from "./acciones.js";

export default function gastosReducer(state = [], action) {
  switch (action.type) {
    case AGREGAR_GASTO:
      return [...state, action.payload];
    case ELIMINAR_GASTO:
      return state.filter((gasto) => gasto.id !== action.payload);
    default:
      return state;
  }
}
