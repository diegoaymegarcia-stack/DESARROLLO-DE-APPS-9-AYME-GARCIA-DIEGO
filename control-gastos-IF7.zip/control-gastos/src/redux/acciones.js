export const AGREGAR_GASTO = "AGREGAR_GASTO";
export const ELIMINAR_GASTO = "ELIMINAR_GASTO";

export const agregarGasto = (gasto) => ({ type: AGREGAR_GASTO, payload: gasto });
export const eliminarGasto = (id) => ({ type: ELIMINAR_GASTO, payload: id });
