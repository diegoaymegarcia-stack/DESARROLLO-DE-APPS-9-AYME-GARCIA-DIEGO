import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { agregarGasto, eliminarGasto } from "./redux/acciones.js";
import ResumenGastos from "./components/ResumenGastos.jsx";

export default function App() {
  const dispatch = useDispatch();
  const gastos = useSelector((state) => state);
  const [descripcion, setDescripcion] = useState("");
  const [monto, setMonto] = useState("");
  const [categoria, setCategoria] = useState("Comida");

  function guardar(e) {
    e.preventDefault();
    if (
      !descripcion.trim() ||
      !Number.isFinite(Number(monto)) ||
      Number(monto) <= 0
    )
      return;
    dispatch(
      agregarGasto({
        id: crypto.randomUUID(),
        descripcion: descripcion.trim(),
        monto: Number(monto),
        categoria,
      }),
    );
    setDescripcion("");
    setMonto("");
  }

  return (
    <main className="contenedor">
      <header>
        <span className="marca">
          NEXO <b>GASTOS</b>
        </span>
        <p>Organiza tu dinero sin complicarte.</p>
      </header>
      <ResumenGastos />
      <section className="panel">
        <h2>Nuevo gasto</h2>
        <form onSubmit={guardar}>
          <label>
            Descripción
            <input
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              placeholder="Ej. Almuerzo"
              required
            />
          </label>
          <label>
            Monto (S/)
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={monto}
              onChange={(e) => setMonto(e.target.value)}
              placeholder="0.00"
              required
            />
          </label>
          <label>
            Categoría
            <select
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
            >
              <option>Comida</option>
              <option>Transporte</option>
              <option>Estudios</option>
              <option>Otros</option>
            </select>
          </label>
          <button type="submit">+ Agregar gasto</button>
        </form>
      </section>
      <section className="panel">
        <h2>Mis gastos</h2>
        {gastos.length === 0 ? (
          <p className="vacio">Todavía no registraste gastos.</p>
        ) : (
          gastos.map((gasto) => (
            <article className="gasto" key={gasto.id}>
              <div>
                <strong>{gasto.descripcion}</strong>
                <small>{gasto.categoria}</small>
              </div>
              <span>S/ {gasto.monto.toFixed(2)}</span>
              <button
                className="eliminar"
                onClick={() => dispatch(eliminarGasto(gasto.id))}
              >
                Eliminar
              </button>
            </article>
          ))
        )}
      </section>
    </main>
  );
}
