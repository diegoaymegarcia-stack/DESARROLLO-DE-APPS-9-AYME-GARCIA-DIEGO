import gastosReducer from "./src/redux/gastosReducer.js";
import { agregarGasto, eliminarGasto } from "./src/redux/acciones.js";

const inicial = [];
const agregado = gastosReducer(inicial, agregarGasto({ id: 1, descripcion: "Almuerzo", monto: 15, categoria: "Comida" }));
const eliminado = gastosReducer(agregado, eliminarGasto(1));
console.assert(inicial.length === 0, "Se mutó el arreglo original");
console.assert(agregado.length === 1, "Error al agregar");
console.assert(eliminado.length === 0, "Error al eliminar");
console.log("Inicial:", inicial);
console.log("Después de agregar:", agregado);
console.log("Después de eliminar:", eliminado);
